etape 1 commencée a 10h le temps de lire le sujet, mettre en place git, l'environnement virtuel

problemes avec git pour l'etape 1 pendant 40 minutes, seulement 20 minutes sur l'etape 2