import pandas as pd
import os

dirname = os.path.dirname(__file__)
# declaration des chemins relatifs
RELATIVE_FILEPATH_ASSOCIATIONS='../data/associations.csv'
RELATIVE_FILEPATH_MATERIEL='../data/materiel.csv'
RELATIVE_FILEPATH_RESERVATIONS='../data/reservations.csv'
RELATIVE_FILEPATH_SITES='../data/sites.csv'

filepath_associations=os.path.join(dirname, RELATIVE_FILEPATH_ASSOCIATIONS)
filepath_materiel=os.path.join(dirname, RELATIVE_FILEPATH_MATERIEL)
filepath_reservations=os.path.join(dirname, RELATIVE_FILEPATH_RESERVATIONS)
filepath_sites=os.path.join(dirname, RELATIVE_FILEPATH_SITES)

df_associations=pd.read_csv(filepath_associations)
df_materiel=pd.read_csv(filepath_materiel)
df_reservations=pd.read_csv(filepath_reservations, parse_dates=["date_debut", "date_fin_prevue", "date_retour_reelle"])
df_sites=pd.read_csv(filepath_sites)

print("df materiel :")
print(f"shape : {df_materiel.shape}")
print(f"infos :")
print(df_materiel.info())
print(f"infos :")
print(df_materiel.isna().sum())

print("df reservations :")
print(f"shape : {df_reservations.shape}")
print(f"infos :")
print(df_reservations.info())
print(f"infos :")
print(df_reservations.isna().sum())

df_materiel["valeur_achat"]=df_materiel["valeur_achat"].replace(",", ".", regex=True)
df_materiel=df_materiel.astype({"valeur_achat" : float})
# La colonne valeur_achat contient des virgules au lieu de points

print("materiels les plus chers :")
df_materiel_chers=(
    df_materiel[["reference", "designation", "categorie", "valeur_achat"]]
    .sort_values(by=["valeur_achat"])
)
print(df_materiel_chers)

print("nombre de materiel par categorie:")
df_materiel_categorie=(
    df_materiel.value_counts("categorie")
)
print(df_materiel_categorie)

print("nombre de reservation et quantite totale par site :")
df_reservations_quantite=(
    df_reservations.groupby("code_site")
    .agg(
        nb_reservation=("id_reservation", "count"),
        quantite_totale=("quantite", "sum")
    )
    .reset_index()
    .sort_values(by="nb_reservation", ascending=False)
)
print(df_reservations_quantite)

# Dataframe complet
df_complet=(
    df_reservations
    .merge(df_materiel.drop_duplicates(), on="id_materiel", how="left")
    .merge(df_associations, on="id_association", how="inner")
)
print(f"Nombre de lignes sur df_complet : {len(df_complet)}")
print(f"Nombre de ligne sans materiel : {df_complet["reference"].isna().sum()}")

print("Top 10 des matériels les plus resérves :")
top_10=(
    df_complet.groupby(["id_materiel", "designation"])["id_reservation"].count()
    .reset_index()
    .rename(columns={"id_reservation" : "nb_reservation"})
    .sort_values("nb_reservation", ascending=False)
    .head(10)
)
print(top_10)
top_10.to_csv("sorties/top10_materiel.csv", encoding='UTF-8', index=False)