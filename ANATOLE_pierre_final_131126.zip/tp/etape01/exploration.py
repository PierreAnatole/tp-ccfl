import csv
from collections import Counter
import os

dirname = os.path.dirname(__file__)
# declaration des chemins relatifs
RELATIVE_FILEPATH_ASSOCIATIONS='../data/associations.csv'
RELATIVE_FILEPATH_MATERIEL='../data/materiel.csv'
RELATIVE_FILEPATH_RESERVATIONS='../data/reservations.csv'
RELATIVE_FILEPATH_SITES='../data/sites.csv'

# chemins a utiliser dans le code
filepath_associations=os.path.join(dirname, RELATIVE_FILEPATH_ASSOCIATIONS)
filepath_materiel=os.path.join(dirname, RELATIVE_FILEPATH_MATERIEL)
filepath_reservations=os.path.join(dirname, RELATIVE_FILEPATH_RESERVATIONS)
filepath_sites=os.path.join(dirname, RELATIVE_FILEPATH_SITES)

def lire_csv(chemin):
    with open(chemin, "r", encoding='UTF-8') as f:
        data_iterator = csv.DictReader(f)
        data=[]
        for ligne in data_iterator:
            data.append(ligne)
    return data

def compter_par(lignes, colonne) :
    column=[e[colonne] for e in lignes]
    count=Counter(column)
    return count

def total_par(lignes, colonne_groupe, colonne_valeur) :
    result={}
    for l in lignes :
        if l[colonne_groupe] in result :
            result[l[colonne_groupe]]=int(result[l[colonne_groupe]])+int(l[colonne_valeur])
        else :
            result[l[colonne_groupe]]=l[colonne_valeur]
    return result

class Site() :

    def __init__(self, code_site, nom, commune, annee_ouverture, surface_m2):
        self.code_site=code_site
        self.nom=nom
        self.commune=commune
        self.annee_ouverture=int(annee_ouverture)
        self.surface_m2=int(surface_m2)

    def anciennete(self, annee_reference):
        return annee_reference-self.annee_ouverture

    def __str__(self) :
        return f"{self.code_site} - {self.nom} ({self.commune}), {self.surface_m2} m2, ouverte en {self.annee_ouverture}"

def reservations_en_cours(reservations) :
    return compter_par(reservations, "date_retour_reelle")[""]

def main() :
    associations=lire_csv(filepath_associations)
    materiel=lire_csv(filepath_materiel)
    reservations=lire_csv(filepath_reservations)
    sites=lire_csv(filepath_sites)

    print(f"""Nombre d' associations : {len(associations)}
Nombre de materiel : {len(materiel)}
Nombre de reservations : {len(reservations)}
Nombre de sites : {len(sites)}
""")

    print("anciennete par site :")
    for s in sites :
        site=Site(s["code_site"], s["nom"], s["commune"], int(s["annee_ouverture"]), int(s["surface_m2"]))
        print(f"{site}, anciennete : {site.anciennete(2026)} ans")

    print("\nnb reservations par site :")
    nb_reservation=compter_par(reservations, "code_site")
    nb_reservation = list(reversed(sorted(nb_reservation.items(), key=lambda kv: kv[1])))

    for r in nb_reservation :
        print(f"{r[0]} : {r[1]} reservations")

    print("\nquantite reservée par site :")
    groupe_reservation=total_par(reservations, "code_site", "quantite")
    groupe_reservation = list(reversed(sorted(groupe_reservation.items(), key=lambda kv: kv[1])))
    for r in groupe_reservation :
        print(f"{r[0]} : {r[1]} quantite reservee")

    print("\nnb materiel par etat :")
    nb_materiel=compter_par(materiel, "etat")
    for k, v in nb_materiel.items() :
        print(f"{k} : {v} materiel")

    print(f"\nNombre de catégories de materiel : {len(compter_par(materiel, 'categorie'))}")
    
    print(f"\nNombre de reservations en cours : {reservations_en_cours(reservations)}")

if __name__ == "__main__" :
    main()