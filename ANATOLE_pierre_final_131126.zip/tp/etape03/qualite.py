import pandas as pd
import numpy as np
import datetime
import os

dirname = os.path.dirname(__file__)
# declaration des chemins relatifs
RELATIVE_FILEPATH_ASSOCIATIONS='../data/associations.csv'
RELATIVE_FILEPATH_MATERIEL='../data/materiel.csv'
RELATIVE_FILEPATH_RESERVATIONS='../data/reservations.csv'
RELATIVE_FILEPATH_SITES='../data/sites.csv'

# sorties
relative_path_materiel_sortie='sorties/materiel_propre.csv'
relative_path_associations_sortie='sorties/associations_propre.csv'
relative_path_reservations_sortie='sorties/reservations_propre.csv'

relative_path_rapport="sorties/rapport_qualite.md"

# utilisé dans le code
filepath_associations=os.path.join(dirname, RELATIVE_FILEPATH_ASSOCIATIONS)
filepath_materiel=os.path.join(dirname, RELATIVE_FILEPATH_MATERIEL)
filepath_reservations=os.path.join(dirname, RELATIVE_FILEPATH_RESERVATIONS)
filepath_sites=os.path.join(dirname, RELATIVE_FILEPATH_SITES)

# dataframes
df_associations=pd.read_csv(filepath_associations)
df_materiel=pd.read_csv(filepath_materiel)
df_reservations=pd.read_csv(filepath_reservations, parse_dates=["date_debut", "date_fin_prevue", "date_retour_reelle"])
df_sites=pd.read_csv(filepath_sites)

# supprime le rapport si il existe deja pour pouvoir relancer le programme
if os.path.exists(relative_path_rapport):
    os.remove(relative_path_rapport)
    with open(relative_path_rapport, "a", encoding="UTF-8") as f:
        text="""|Fichier|Colonne|Description|Nb Lignes|% Lignes|traitement|
|---|---|---|---|---|---|
"""
        f.write(text)

# classe representant une anomalie, avec :
# une description de l'anomalie
# le nom du fichier concerné
# la colonne concernée (ou 'toutes')
# le traitement choisi
# le dataframe concerné
# le filtre utilisé pour isoler les lignes concernées par l'anomalie 
class Anomalie() :
    rapport_filepath=relative_path_rapport
    traitement_to_str={"SUPPRESSION" : "suppression",
                       "AUCUN" : "pas d'action",
                       "STRIP_CAPITALIZE" : "capitalization + strip",
                       "VIRGULE_POINT" : "remplace les virgules decimales par un point",
                       "TYPE_INCONNU" : "remplace par des NaN",
                       "FORMAT_DATE" : "formatage de la date dans le bon format"
    }

    def __init__(self, description, fichier, colonne, traitement, data, filtre):
        self.description=description
        self.fichier=fichier
        self.colonne=colonne
        self.traitement=traitement
        self.data=data
        self.filtre=filtre

    def lignes_concernees(self):
        # renvoie les lignes concernees
        return self.data[self.filtre]

    def echantillon_concernees_sysout(self):
        # print un echantillon des lignes concernées et le nombre concerne
        print(f"""
Anomalie : {self.description}
Nombre de lignes concernées : {self.nb_lignes_concernees()}
Echantillon :""")
        lignes = self.lignes_concernees()
        if len(lignes) <= 3 :
            print(lignes)
        else :
            print(lignes.head(3))
        print()

    def nb_lignes_concernees (self) :
        # renvoie le nombre de lignes concernees
        return (self.filtre.sum())

    def pourcentage_du_fichier(self) :
        # renvoie le pourcentage de lignes concernees
        return round((self.nb_lignes_concernees()/len(self.data))*100,2)

    def nettoie_donnee(self) :
        # effectue l'action en fonction du traitement choisi
        if self.traitement=="AUCUN" :
            return self.data
        elif self.traitement=="SUPPRESSION" :
            return self.data[~(self.filtre)]
        elif self.traitement=="STRIP_CAPITALIZE" :
            new_data=self.data.copy()
            new_data[self.colonne]=new_data[self.colonne].str.strip().str.capitalize()
            return new_data
        elif self.traitement=="VIRGULE_POINT" :
            new_data=self.data.copy()
            new_data[self.colonne]=new_data[self.colonne].str.replace(",", ".")
            return new_data
        elif self.traitement=="TYPE_INCONNU" :
            new_data=self.data.copy()
            new_data.loc[new_data[self.colonne]=="inconnu", self.colonne]=np.nan
            return new_data
        elif self.traitement=="FORMAT_DATE" :
            new_data=self.data.copy()
            wrong_format=pd.to_datetime(new_data[self.colonne], format="mixed").dt.strftime('%d/%m/%Y')
            right_format=pd.to_datetime(wrong_format, format="mixed").dt.strftime('%Y-%m-%d')
            new_data[self.colonne]=right_format
            return new_data
        
    def rapport_markdown(self):
    # genere un resumé de l'anomalie dans le markdown, a la suite
        with open(self.rapport_filepath, "a", encoding="UTF-8") as f:
            c1=self.fichier
            c2=f"`{self.colonne}`"
            c3=self.description
            c4=self.nb_lignes_concernees()
            c5=f"{self.pourcentage_du_fichier()}%"
            c6=self.traitement_to_str[self.traitement]
            text=f"|{c1}|{c2}|{c3}|{c4}|{c5}|{c6}|\n"
            f.write(text)

# main
###########################################################################
### materiel.csv
df_materiel_filtre=df_materiel.copy()

# doublons stricts
anomalie_m1=Anomalie(
    description="Doublon strict",
    fichier="documents.csv",
    colonne="toutes",
    traitement="SUPPRESSION",
    data=df_materiel_filtre,
    filtre=df_materiel_filtre.duplicated()
)
anomalie_m1.echantillon_concernees_sysout()
anomalie_m1.rapport_markdown()
df_materiel_filtre=anomalie_m1.nettoie_donnee()

# annee_achat vide
anomalie_m2=Anomalie(
    description="Annee d'achat vide",
    fichier="documents.csv",
    colonne="annee_achat",
    traitement="AUCUN",
    data=df_materiel_filtre,
    filtre=df_materiel_filtre["annee_achat"].isna()
)
anomalie_m2.echantillon_concernees_sysout()
anomalie_m2.rapport_markdown()
df_materiel_filtre=anomalie_m2.nettoie_donnee()

# annee_achat postérieure à l'année courante
anne_courante=datetime.datetime.now().year
anomalie_m3=Anomalie(
    description="Annee d'achat > annee courante",
    fichier="documents.csv",
    colonne="annee_achat",
    traitement="SUPPRESSION",
    data=df_materiel_filtre,
    filtre=df_materiel_filtre["annee_achat"]>anne_courante
)
anomalie_m3.echantillon_concernees_sysout()
anomalie_m3.rapport_markdown()
df_materiel_filtre=anomalie_m3.nettoie_donnee()

# valeur_achat vide
anomalie_m4=Anomalie(
    description="Valeur d'achat vide",
    fichier="documents.csv",
    colonne="valeur_achat",
    traitement="AUCUN",
    data=df_materiel_filtre,
    filtre=df_materiel_filtre["valeur_achat"].isna()
)
anomalie_m4.echantillon_concernees_sysout()
anomalie_m4.rapport_markdown()
df_materiel_filtre=anomalie_m4.nettoie_donnee()

# categorie mal formatée (espaces en debut et fin, majuscule)
list_categories=df_materiel_filtre["categorie"].str.strip().str.capitalize()
anomalie_m5=Anomalie(
    description="espaces parasites, uppercase",
    fichier="documents.csv",
    colonne="categorie",
    traitement="STRIP_CAPITALIZE",
    data=df_materiel_filtre,
    filtre=(~df_materiel_filtre["categorie"].isin(list_categories))
)
anomalie_m5.echantillon_concernees_sysout()
anomalie_m5.rapport_markdown()
df_materiel_filtre=anomalie_m5.nettoie_donnee()

# valeur d'achat ecrit avec une virgule décimale
# print(df_materiel_filtre[df_materiel_filtre["valeur_achat"].str.contains(",")])
anomalie_m6=Anomalie(
    description="Virgule décimale",
    fichier="documents.csv",
    colonne="valeur_achat",
    traitement="VIRGULE_POINT",
    data=df_materiel_filtre,
    filtre=df_materiel_filtre["valeur_achat"].str.contains(",")
)
anomalie_m6.echantillon_concernees_sysout()
anomalie_m6.rapport_markdown()
df_materiel_filtre=anomalie_m6.nettoie_donnee()

### associations.csv
df_associations_filtre=df_associations.copy()

# code_postal vide
anomalie_a1=Anomalie(
    description="code postal vide",
    fichier="associations.csv",
    colonne="code_postal",
    traitement="AUCUN",
    data=df_associations_filtre,
    filtre=df_associations_filtre["code_postal"].isna()
)
anomalie_a1.echantillon_concernees_sysout()
anomalie_a1.rapport_markdown()
df_associations_filtre=anomalie_a1.nettoie_donnee()

# type d'association valant inconnu
anomalie_a2=Anomalie(
    description="type d'association valant 'inconnu'",
    fichier="associations.csv",
    colonne="type_association",
    traitement="TYPE_INCONNU",
    data=df_associations_filtre,
    filtre=df_associations_filtre["type_association"]=="inconnu"
)
anomalie_a2.echantillon_concernees_sysout()
anomalie_a2.rapport_markdown()
df_associations_filtre=anomalie_a2.nettoie_donnee()

# mauvais format de date sur date_convention
anomalie_a3=Anomalie(
    description="format de date incorrect",
    fichier="associations.csv",
    colonne="date_convention",
    traitement="FORMAT_DATE",
    data=df_associations_filtre,
    filtre=df_associations_filtre["date_convention"].str.contains("/")
)
anomalie_a3.echantillon_concernees_sysout()
anomalie_a3.rapport_markdown()
df_associations_filtre=anomalie_a3.nettoie_donnee()

### reservations.csv
df_reservations_filtre=df_reservations.copy()

# doublons stricts
anomalie_r1=Anomalie(
    description="Doublon strict",
    fichier="reservations.csv",
    colonne="toutes",
    traitement="SUPPRESSION",
    data=df_reservations_filtre,
    filtre=df_reservations_filtre.duplicated()
)
anomalie_r1.echantillon_concernees_sysout()
anomalie_r1.rapport_markdown()
df_materiel_filtre=anomalie_r1.nettoie_donnee()

# id_materiel non present dans meteriel.csv
# TODO

# Exports csv
df_materiel_filtre.to_csv(relative_path_materiel_sortie, index=False)
df_associations_filtre.to_csv(relative_path_associations_sortie, index=False)
df_reservations_filtre.to_csv(relative_path_reservations_sortie, index=False)