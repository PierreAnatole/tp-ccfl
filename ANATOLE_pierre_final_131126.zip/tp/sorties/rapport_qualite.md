|Fichier|Colonne|Description|Nb Lignes|% Lignes|traitement|
|---|---|---|---|---|---|
|documents.csv|`toutes`|Doublon strict|7|1.91%|suppression|
|documents.csv|`annee_achat`|Annee d'achat vide|8|2.22%|pas d'action|
|documents.csv|`annee_achat`|Annee d'achat > annee courante|5|1.39%|suppression|
|documents.csv|`valeur_achat`|Valeur d'achat vide|11|3.1%|pas d'action|
|documents.csv|`categorie`|espaces parasites, uppercase|11|3.1%|capitalization + strip|
|documents.csv|`valeur_achat`|Virgule décimale|4|1.13%|remplace les virgules decimales par un point|
|associations.csv|`code_postal`|code postal vide|9|4.29%|pas d'action|
|associations.csv|`type_association`|type d'association valant 'inconnu'|7|3.33%|remplace par des NaN|
|associations.csv|`date_convention`|format de date incorrect|6|2.86%|formatage de la date dans le bon format|
|reservations.csv|`toutes`|Doublon strict|18|0.39%|suppression|
