import pandas as pd
import os

dirname = os.path.dirname(__file__)
# declaration des chemins relatifs
RELATIVE_FILEPATH_ASSOCIATIONS='../data/associations.csv'
RELATIVE_FILEPATH_MATERIEL='../data/materiel.csv'
RELATIVE_FILEPATH_RESERVATIONS='../data/reservations.csv'
RELATIVE_FILEPATH_SITES='../data/sites.csv'

filepath_associations=os.path.join(dirname, RELATIVE_FILEPATH_ASSOCIATIONS)
filepath_materiel=os.path.join(dirname, RELATIVE_FILEPATH_MATERIEL)
filepath_reservations=os.path.join(dirname, RELATIVE_FILEPATH_RESERVATIONS)
filepath_sites=os.path.join(dirname, RELATIVE_FILEPATH_SITES)

df_associations=pd.read_csv(filepath_associations)
df_materiel=pd.read_csv(filepath_materiel)
df_reservations=pd.read_csv(filepath_reservations, parse_dates=["date_debut", "date_fin_prevue", "date_retour_reelle"])
df_sites=pd.read_csv(filepath_sites)

print("df materiel :")
print(f"shape : {df_materiel.shape}")
print(f"infos :")
print(df_materiel.info())
print(f"infos :")
print(df_materiel.isna().sum())

print("df reservations :")
print(f"shape : {df_reservations.shape}")
print(f"infos :")
print(df_reservations.info())
print(f"infos :")
print(df_reservations.isna().sum())

df_materiel["valeur_achat"]=df_materiel["valeur_achat"].replace(",", ".", regex=True)
df_materiel=df_materiel.astype({"valeur_achat" : float})
# La colonne valeur_achat contient des virgules au lieu de points

print("materiels les plus chers :")
df_materiel_chers=(
    df_materiel[["reference", "designation", "categorie", "valeur_achat"]]
    .sort_values(by=["valeur_achat"])
)
print(df_materiel_chers)

print("nombre de materiel par categorie:")
df_materiel_categorie=(
    df_materiel.groupby("categorie")["id_materiel"]
    .count()
)
print(df_materiel_categorie)